<?php

return [
    'stacking_order'=>['percentage','fixed'],
    'max_percentage_cap'=>50,
    'rounding'=>'half_up',
];
