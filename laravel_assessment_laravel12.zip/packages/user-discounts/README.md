User Discounts package (PSR-4)

To use:
1. Add a path repository or publish this package into your app.
2. Run migrations included by the package (`php artisan migrate`).
3. Register service provider or let package auto-discover.
4. Use `UserDiscounts\DiscountService` to apply discounts.

This package includes config, migrations and a basic deterministic apply example.
